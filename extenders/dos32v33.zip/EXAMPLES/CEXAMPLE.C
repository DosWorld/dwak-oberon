/*************************************************************************
            CEXAMPLE.C:         small example C program using PAL.

to compile using Borland C V4.0+

        bcc32 -c cexample.c
        dlink -c cexample.obj c0.obj ,,, pal.lib

where;
pal.lib  = standard library
c0.obj   = startup code





*************************************************************************/

#include    <stdio.h>



	char    *s;
	char  **ss;
	char 	 c;
	unsigned i,n;
        unsigned char *video_pointer;



int main(int argc, char *argv[])
{

char * system;

       *(int*)&video_pointer = 0xA0000 - (int)_zero;


    printf("C example program using PAL.LIB for the standard library.\n\n");

    if (dos32system == 1) system="raw DOS";
    if (dos32system == 2) system="XMS";
    if (dos32system == 4) system="VCPI";
    if (dos32system == 8) system="DPMI";



    fprintf(stdout," Executable file name           %s\n",argv[0]);
    fprintf(stderr," Executable file name           %s\n",argv[0]);
    printf(" Executable file size           %d bytes\n",exesize);
    printf(" Number of command line args    %d\n",argc);
    for (i=0; i < argc; i++ ){
     printf(" arg %d '%s'\n",i,argv[i]);

    }

    printf(" System type                    %s\n",system);
    printf(" DOS32 Version                  %x.%x%x\n",dos32version >> 8,(dos32version >> 4) & 0xF,dos32version & 0xF);
    printf(" Avalible memory                %dK\n",maxavail()>>10);


/**** display the environment ********/
/*       for (i=(ulong)environ ; ; i += sizeof (char *))
      {
        s = *(char **)i;
        if ( *s == 0 ) break;
	printf("%s \n",s);
      } */


    printf("\nPress any key to exit\n");
    for (; !kbhit() ;); 
       getchar();




return EXIT_SUCCESS;
}
