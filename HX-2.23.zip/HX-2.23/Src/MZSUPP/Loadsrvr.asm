
	include loadsrvr.inc
	end

